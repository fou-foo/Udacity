from setuptools import setup

setup(name='distributions_fou_foo',
      version='0.01',
      description='udacity-exercise',
      packages=['distributions_fou_foo'],
      author = 'J. Antonio García',
      author_email='jose.ramirez@cimat.mx',
      zip_safe=False)
